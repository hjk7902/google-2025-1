실행 방법
1. 먼저 필요한 라이브러리를 설치하세요.
pip install fastapi openia jinja2 uvicorn

2. main.py 파일을 실행하세요.
python main.py

3. 서버가 실행되면 브라우저를 이용해서 "http://localhost:8000"에 연결하세요.

4. 자신의 취향에 맞는 영화를 추천 받을 수 있습니다.