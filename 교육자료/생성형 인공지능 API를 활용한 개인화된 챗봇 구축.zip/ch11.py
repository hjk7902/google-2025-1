from fastapi import FastAPI, Request, Query
from fastapi.responses import StreamingResponse, HTMLResponse
from fastapi.templating import Jinja2Templates # pip install jinja2
from pydantic import BaseModel
from openai import OpenAI
import asyncio
import json
from io import BytesIO
import wave

app = FastAPI()


# 템플릿 디렉토리 설정
templates = Jinja2Templates(directory="templates")

client = OpenAI(
    api_key= "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"
)

# 파일에서 프롬프트 내용을 읽어오는 함수
def load_prompt(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        prompt = file.read().strip()
    return prompt

movie_prompt = load_prompt("movie_prompt.txt")


messages = [{"role": "system","content": movie_prompt}]


# 요청 본문 모델 정의
class ChatRequest(BaseModel):
    prompt: str


@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("ch11.html", {"request": request})


@app.get("/chat_stream")
async def chat_stream(prompt: str = Query(...)):
    messages.append({"role": "user", "content": prompt})

    async def event_stream():
        stream = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            stream=True
        )

        for chunk in stream:
            content = chunk.choices[0].delta.content
            if content:
                data = f"data: {json.dumps({'status': 'processing', 'data': content}, ensure_ascii=False)}\n\n"
                yield data
                await asyncio.sleep(0)  # 다른 작업을 수행할 수 있도록 컨텍스트 스위칭

        yield f"data: {json.dumps({'status': 'complete', 'data': 'finished'}, ensure_ascii=False)}\n\n"

    headers = {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
    }

    return StreamingResponse(event_stream(), headers=headers)



# PCM 데이터를 WAV로 변환하는 함수
def pcm_to_wav(pcm_data):
    wav_io = BytesIO()
    with wave.open(wav_io, "wb") as wav_file:
        wav_file.setnchannels(1)  # Mono channel
        wav_file.setsampwidth(2)  # 16-bit PCM
        wav_file.setframerate(24000)  # 24 kHz sample rate
        wav_file.writeframes(pcm_data)
    wav_io.seek(0)
    return wav_io


# 음성 스트리밍 엔드포인트
@app.get("/audio_stream")
async def audio_stream(prompt: str = Query(..., description="Text to convert to speech")):
    messages.append({"role": "user", "content": prompt})

    chat_response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=messages,
    )
    text = chat_response.choices[0].message.content

    async def audio_event_stream():
        pcm_data = BytesIO()
        with client.audio.speech.with_streaming_response.create(
                model="tts-1",
                voice="alloy",
                input=text,
                response_format="pcm"
        ) as response:
            for chunk in response.iter_bytes(1024):
                pcm_data.write(chunk)
                await asyncio.sleep(0)

        pcm_data.seek(0)
        wav_audio = pcm_to_wav(pcm_data.read())
        return wav_audio

    wav_stream = await audio_event_stream()
    headers = {
        "Content-Type": "audio/wav",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
    }

    return StreamingResponse(wav_stream, headers=headers, media_type="audio/wav")


# 음성 변환 엔드포인트
@app.post("/convert_text_to_speech")
async def convert_text_to_speech(request: Request):
    data = await request.json()
    text = data.get("text")

    # TTS 변환 코드
    pcm_data = BytesIO()
    with client.audio.speech.with_streaming_response.create(
            model="tts-1",
            voice="alloy",
            input=text,
            response_format="pcm"
    ) as response:
        for chunk in response.iter_bytes(1024):
            pcm_data.write(chunk)
            await asyncio.sleep(0)

    pcm_data.seek(0)
    wav_audio = pcm_to_wav(pcm_data.read())
    return StreamingResponse(wav_audio, media_type="audio/wav")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
