from openai import OpenAI
client = OpenAI(
    api_key= "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"
)

completion = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[
        {"role": "user", "content": "Say this is a test."}
    ]
)

print(completion.choices[0].message.content)