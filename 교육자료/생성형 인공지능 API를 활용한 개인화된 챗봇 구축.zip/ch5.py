from fastapi import FastAPI, Request, Query
from fastapi.responses import StreamingResponse, HTMLResponse
from fastapi.templating import Jinja2Templates # pip install jinja2
from pydantic import BaseModel
from openai import OpenAI
import asyncio
import json

app = FastAPI()


# 템플릿 디렉토리 설정
templates = Jinja2Templates(directory="templates")

client = OpenAI(
    api_key= "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"
)

# 파일에서 프롬프트 내용을 읽어오는 함수
def load_prompt(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        prompt = file.read().strip()
    return prompt

movie_prompt = load_prompt("movie_prompt.txt")


messages = [{"role": "system","content": movie_prompt}]


# 요청 본문 모델 정의
class ChatRequest(BaseModel):
    prompt: str


@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("ch5.html", {"request": request})


@app.get("/chat_stream")
async def chat_stream(prompt: str = Query(...)):
    local_messages = [{"role": "system", "content": movie_prompt}]
    local_messages.append({"role": "user", "content": prompt})

    async def event_stream():
        stream = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=local_messages,
            stream=True
        )
        for chunk in stream:
            content = chunk.choices[0].delta.content
            if content:
                data = f"data: {json.dumps({'status': 'processing', 'data': content}, ensure_ascii=False)}\n\n"
                yield data
                await asyncio.sleep(0)  # 다른 작업을 수행할 수 있도록 컨텍스트 스위칭
        yield f"data: {json.dumps({'status': 'complete', 'data': 'finished'}, ensure_ascii=False)}\n\n"

    headers = {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
    }

    return StreamingResponse(event_stream(), headers=headers)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
