from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")

client = OpenAI(
    api_key = api_key
)

response = client.images.edit(
  model="dall-e-2",
  image=open("background.png", "rb"),
  mask=open("mask.png", "rb"),
  prompt="An indoor image of a pool with a Labrador retriever dog sitting on the floor",
  n=1,
  size="1024x1024"
)

print(response.data[0].url)

