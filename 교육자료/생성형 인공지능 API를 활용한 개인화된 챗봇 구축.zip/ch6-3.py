from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")

client = OpenAI(
    api_key = api_key
)

response = client.images.create_variation(
    image=open("cat-and-dog.png", "rb"),
    n=2,
    size="1024x1024"
)

print(response.data[0].url)
print(response.data[1].url)

