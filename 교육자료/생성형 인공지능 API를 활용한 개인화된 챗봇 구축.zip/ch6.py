from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")

client = OpenAI(
    api_key = api_key
)

response = client.images.generate(
    model="dall-e-3",
    prompt="겨울, 우주, 아름다운, 마녀, 판타지, 코어, 생물, 초현실적, 밝은 이미지를 그려줘",
    size="1024x1024",
    quality="standard",
    n=1,
)

print(response.data[0].url)

