from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")

client = OpenAI(api_key=api_key)


with client.audio.speech.with_streaming_response.create(
    model="tts-1",
    voice="alloy",
    input="오늘은 내가 가장 행복한 날입니다."
) as response:
    response.stream_to_file("speech-alloy.mp3")
