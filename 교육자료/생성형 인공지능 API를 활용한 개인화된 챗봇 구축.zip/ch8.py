from openai import OpenAI
import os
from dotenv import load_dotenv
import requests
import json

# 환경 변수 로드
load_dotenv()
openai_api_key = os.getenv("OPENAI_API_KEY")
weather_api_key = os.getenv("OPENWEATHER_API_KEY")

client = OpenAI(api_key=openai_api_key)

# 함수 정의
functions = [
    {
        "name": "get_weather",
        "description": "특정 도시의 날씨 정보를 반환합니다.",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {
                    "type": "string",
                    "description": "날씨 정보를 가져올 도시의 이름을 영어로"
                }
            },
            "required": ["city"]
        }
    }
]

# 날씨 정보 가져오는 함수
def get_weather(city):
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={weather_api_key}&units=metric"
    response = requests.get(url)
    data = response.json()
    weather = data['weather'][0]['description']
    temperature = data['main']['temp']
    return {
        "city": city,
        "weather": weather,
        "temperature": temperature
    }

# OpenAI API 호출 및 함수 호출 여부 결정
response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[
        {"role": "user", "content": "서울의 날씨가 궁금해"}
    ],
    functions=functions,
    function_call="auto"
)

# 함수 호출이 발생한 경우
if response.choices[0].message.function_call and response.choices[0].message.function_call.name == 'get_weather':
    arguments = json.loads(response.choices[0].message.function_call.arguments)
    city = arguments['city']
    weather_data = get_weather(city)

    # 날씨 정보를 포함한 최종 응답 출력
    print(f"현재 {city}의 날씨는 {weather_data['weather']}이고, 온도는 {weather_data['temperature']}도 입니다.")
else:
    print(response.choices[0].message.content)
