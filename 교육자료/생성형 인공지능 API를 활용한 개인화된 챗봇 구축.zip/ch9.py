from openai import OpenAI
import os
from dotenv import load_dotenv
import PyPDF2

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")

client = OpenAI(
    api_key = api_key
)

def read_pdf(file_path):
     with open(file_path, 'rb') as file:
          reader = PyPDF2.PdfReader(file)
          text = ''
          for page in reader.pages:
               text += page.extract_text()
     return text


def summarize_text(text):
     response = client.chat.completions.create(
          model="gpt-4o-mini",
          temperature=0,
          messages=[
               { "role": "system", "content": "다음 텍스트를 요약해줘" },
               { "role": "user", "content": text }
          ],
          max_tokens=150,  # 요약 길이 설정
     )
     return response.choices[0].message.content


def translate_text(text, lang="영어"):
     response = client.chat.completions.create(
          model="gpt-4o-mini",
          temperature=0,
          messages=[
               { "role": "system", "content": f"다음 텍스트를 {lang}로 번역해줘" },
               { "role": "user", "content": text }
          ],
     )
     return response.choices[0].message.content


# 메인 함수
def process_pdf(pdf_file_path):
     # 1. PDF에서 텍스트 추출
     extracted_text = read_pdf(pdf_file_path)

     # 2. GPT를 사용하여 요약
     summary = summarize_text(extracted_text)

     # 3. GPT를 사용하여 번역
     extracted_text = translate_text(summary, lang="영어")
     return (summary, extracted_text)


# PDF 파일 처리
pdf_file_path = 'newspaper.pdf'
summary, translated_summary = process_pdf(pdf_file_path)
print(f"요약: {summary}")
print(f"번역: {translated_summary}")

