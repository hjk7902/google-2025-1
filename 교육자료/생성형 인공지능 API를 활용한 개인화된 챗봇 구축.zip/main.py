from fastapi import FastAPI, Request, Query
from fastapi.responses import StreamingResponse, HTMLResponse
from fastapi.templating import Jinja2Templates # pip install jinja2
from pydantic import BaseModel
from openai import OpenAI
import asyncio
import json
from io import BytesIO
import wave
from dotenv import load_dotenv
import os

app = FastAPI()


# 템플릿 디렉토리 설정
templates = Jinja2Templates(directory="templates")

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")

client = OpenAI(
    api_key = api_key
)

# 파일에서 프롬프트 내용을 읽어오는 함수
def load_prompt(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        prompt = file.read().strip()
    return prompt

movie_prompt = load_prompt("movie_prompt.txt")


messages = [{"role": "system","content": movie_prompt}]


# 요청 본문 모델 정의
class ChatRequest(BaseModel):
    prompt: str


@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/chat_stream")
async def chat_stream(prompt: str = Query(...)):
    messages.append({"role": "user", "content": prompt})

    async def event_stream():
        stream = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            stream=True
        )

        for chunk in stream:
            content = chunk.choices[0].delta.content
            if content:
                data = f"data: {json.dumps({'status': 'processing', 'data': content}, ensure_ascii=False)}\n\n"
                yield data
                await asyncio.sleep(0)  # 다른 작업을 수행할 수 있도록 컨텍스트 스위칭

        yield f"data: {json.dumps({'status': 'complete', 'data': 'finished'}, ensure_ascii=False)}\n\n"

    headers = {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
    }

    return StreamingResponse(event_stream(), headers=headers)



# PCM 데이터를 WAV로 변환하는 함수
def pcm_to_wav(pcm_data):
    wav_io = BytesIO()
    with wave.open(wav_io, "wb") as wav_file:
        wav_file.setnchannels(1)  # Mono channel
        wav_file.setsampwidth(2)  # 16-bit PCM
        wav_file.setframerate(24000)  # 24 kHz sample rate
        wav_file.writeframes(pcm_data)
    wav_io.seek(0)
    return wav_io


# 음성 스트리밍 엔드포인트
@app.get("/audio_stream")
async def audio_stream(prompt: str = Query(..., description="Text to convert to speech")):
    messages.append({"role": "user", "content": prompt})

    chat_response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=messages,
    )
    text = chat_response.choices[0].message.content

    async def audio_event_stream():
        pcm_data = BytesIO()
        with client.audio.speech.with_streaming_response.create(
                model="tts-1",
                voice="alloy",
                input=text,
                response_format="pcm"
        ) as response:
            for chunk in response.iter_bytes(1024):
                pcm_data.write(chunk)
                await asyncio.sleep(0)

        pcm_data.seek(0)
        wav_audio = pcm_to_wav(pcm_data.read())
        return wav_audio

    wav_stream = await audio_event_stream()
    headers = {
        "Content-Type": "audio/wav",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
    }

    return StreamingResponse(wav_stream, headers=headers, media_type="audio/wav")


# 음성 변환 엔드포인트
@app.post("/convert_text_to_speech")
async def convert_text_to_speech(request: Request):
    data = await request.json()
    text = data.get("text")

    # TTS 변환 코드
    pcm_data = BytesIO()
    with client.audio.speech.with_streaming_response.create(
            model="tts-1",
            voice="alloy",
            input=text,
            response_format="pcm"
    ) as response:
        for chunk in response.iter_bytes(1024):
            pcm_data.write(chunk)
            await asyncio.sleep(0)

    pcm_data.seek(0)
    wav_audio = pcm_to_wav(pcm_data.read())
    return StreamingResponse(wav_audio, media_type="audio/wav")


@app.get("/audio_stream_with_text")
async def audio_stream_with_text(prompt: str = Query(..., description="Enter text for movie recommendation")):
    """
    영화 추천 텍스트와 음성 스트리밍을 함께 반환합니다.
    """
    # 1. 영화 추천 생성
    messages.append({"role": "user", "content": prompt})

    # GPT 모델로부터 영화 추천 받기
    chat_response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=messages
    )
    movie_recommendations = chat_response.choices[0].message.content.strip()

    # 2. 음성 스트리밍 데이터 생성
    async def audio_event_stream():
        pcm_data = BytesIO()
        with client.audio.speech.with_streaming_response.create(
                model="tts-1",
                voice="alloy",
                input=movie_recommendations,
                response_format="pcm"
        ) as response:
            for chunk in response.iter_bytes(1024):
                pcm_data.write(chunk)
                await asyncio.sleep(0)  # 스트리밍 대기

        pcm_data.seek(0)
        wav_audio = pcm_to_wav(pcm_data.read())
        # print(f"Generated WAV size: {len(wav_audio.read())} bytes")
        return wav_audio

    # WAV 데이터 준비
    wav_stream = await audio_event_stream()
    print(f"Generated WAV: {wav_stream} bytes")
    # with open("test.wav", "wb") as f:
    #     f.write(wav_stream.read()) # 파일이 저장되면 윈도우에서 실행해 보세요. 테스트 후 주석처리해야 합니다.

    # 3. JSON 데이터와 WAV 데이터를 병합하여 반환
    boundary = "movieAudioBoundary"  # Multipart boundary 설정

    async def generate_multipart_response():
        # JSON 파트
        json_data = json.dumps({"recommendations": movie_recommendations}, ensure_ascii=False).encode("utf-8")
        yield f"--{boundary}\r\nContent-Type: application/json\r\n\r\n".encode("utf-8")
        yield json_data
        yield b"\r\n"

        # Audio 파트
        yield f"--{boundary}\r\nContent-Type: audio/wav\r\n\r\n".encode("utf-8")
        yield wav_stream.read()  # WAV 파일 스트림
        yield b"\r\n"

        # Boundary 종료
        yield f"--{boundary}--\r\n".encode("utf-8")

    headers = {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": f"multipart/mixed; boundary={boundary}",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
    }

    return StreamingResponse(generate_multipart_response(), headers=headers)


@app.get("/stream_text_and_audio")
async def stream_text_and_audio(prompt: str = Query(..., description="Enter text for movie recommendation")):
    """
    텍스트 데이터를 먼저 스트리밍하고, 그 뒤에 음성 데이터를 반환합니다.
    """
    messages.append({"role": "user", "content": prompt})

    async def event_stream():
        # 1. 텍스트 데이터 스트리밍
        stream = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            stream=True
        )
        movie_recommendations = ''
        for chunk in stream:
            content = chunk.choices[0].delta.content
            if content:
                movie_recommendations += content
                data = f"data: {json.dumps({'status': 'processing', 'data': content}, ensure_ascii=False)}\n\n"
                print(content, end='')
                yield data
                await asyncio.sleep(0)  # 컨텍스트 스위칭 허용

        yield f"data: {json.dumps({'status': 'complete', 'data': 'finished'}, ensure_ascii=False)}\n\n"

        # 2. 음성 데이터 스트리밍
        yield f"data: {json.dumps({'status': 'audio', 'data': 'Audio stream starting'}, ensure_ascii=False)}\n\n"

        pcm_data = BytesIO()
        with client.audio.speech.with_streaming_response.create(
                model="tts-1",
                voice="alloy",
                input=movie_recommendations,
                response_format="pcm"
        ) as response:
            for chunk in response.iter_bytes(1024):
                pcm_data.write(chunk)
                await asyncio.sleep(0)  # 스트리밍 대기

        pcm_data.seek(0)
        wav_audio = pcm_to_wav(pcm_data.read())
        print(wav_audio)
        yield wav_audio.read()

        yield f"data: {json.dumps({'status': 'audio', 'data': 'Audio stream finished'}, ensure_ascii=False)}\n\n"

    headers = {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
    }

    return StreamingResponse(event_stream(), headers=headers)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
