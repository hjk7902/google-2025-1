from fastapi import FastAPI, Request, Query
from fastapi.responses import StreamingResponse, HTMLResponse
from fastapi.templating import Jinja2Templates # pip install jinja2
from openai import OpenAI
import asyncio
from io import BytesIO
import uvicorn
import wave


# 템플릿 디렉토리 설정
templates = Jinja2Templates(directory="templates")

app = FastAPI()


client = OpenAI(
    api_key= "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"
)

# 오디오 설정
sample_rate = 24000
channels = 1
sample_width = 2  # 16-bit PCM (2 bytes per sample)

# PCM 데이터를 WAV로 변환하는 함수
def pcm_to_wav(pcm_data):
    wav_io = BytesIO()
    with wave.open(wav_io, "wb") as wav_file:
        wav_file.setnchannels(channels)
        wav_file.setsampwidth(sample_width)
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(pcm_data)
    wav_io.seek(0)
    return wav_io


@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index2.html", {"request": request})


# 음성 스트리밍 엔드포인트
@app.get("/audio_stream")
async def audio_stream(text: str = Query(..., description="Text to convert to speech")):
    async def audio_event_stream():
        pcm_data = BytesIO()
        with client.audio.speech.with_streaming_response.create(
                model="tts-1",
                voice="alloy",
                input=text,
                response_format="pcm"
        ) as response:
            for chunk in response.iter_bytes(1024):
                pcm_data.write(chunk)
                await asyncio.sleep(0)

        pcm_data.seek(0)
        wav_audio = pcm_to_wav(pcm_data.read())
        return wav_audio

    wav_stream = await audio_event_stream()
    headers = {
        "Content-Type": "audio/wav",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
    }

    return StreamingResponse(wav_stream, headers=headers, media_type="audio/wav")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")