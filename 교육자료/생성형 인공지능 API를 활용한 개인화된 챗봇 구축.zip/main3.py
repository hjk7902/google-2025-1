from fastapi import FastAPI, Request, Query
from fastapi.responses import StreamingResponse, HTMLResponse
from fastapi.templating import Jinja2Templates # pip install jinja2
from pydantic import BaseModel
from openai import OpenAI
from gtts import gTTS
import asyncio
import json
import uvicorn
import os
from dotenv import load_dotenv
from io import BytesIO

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")

app = FastAPI()


# 템플릿 디렉토리 설정
templates = Jinja2Templates(directory="templates")

client = OpenAI(
    api_key= api_key
)

movie_prompt = """당신은 영화 추천을 위해 훈련된 고도로 숙련된 AI입니다.
내가 입력한 단어 또는 문장을 기반으로 영화를 추천해야 합니다.
내가 입력한 단어 또는 문장에는 나의 관심사와 성별, 연령대, 지역 등의 개인정보가 포함될 수 있습니다.
내가 어떤 영화의 제목을 입력하면 유사한 장르의 영화를 추천하세요.
감독 또는 배우의 이름을 입력하면 그 배우가 참여한 다른 영화를 추천하세요.
개인정보를 입력하면 그 그룹에서 인기있는 영화를 추천하세요.
영화 추천은 3편~5편을 해주고, 목록 형식으로 추천해주세요.
"""




# 요청 본문 모델 정의
class ChatRequest(BaseModel):
    prompt: str


@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index3.html", {"request": request})


@app.get("/chat_stream")
async def chat_stream(prompt: str = Query(...)):
    local_messages = [{"role": "system", "content": movie_prompt}]
    local_messages.append({"role": "user", "content": prompt})

    async def event_stream():
        stream = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=local_messages,
            stream=True
        )

        for chunk in stream:
            content = chunk.choices[0].delta.content
            if content:
                data = f"data: {json.dumps({'status': 'processing', 'data': content}, ensure_ascii=False)}\n\n"
                yield data
                await asyncio.sleep(0)  # 다른 작업을 수행할 수 있도록 컨텍스트 스위칭

        yield f"data: {json.dumps({'status': 'complete', 'data': 'finished'}, ensure_ascii=False)}\n\n"

    headers = {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
    }

    return StreamingResponse(event_stream(), headers=headers)


@app.get("/audio_stream")
async def audio_stream(prompt: str = Query(..., description="Movie recommendation prompt")):
    local_messages = [{"role": "system", "content": movie_prompt+" 결과는 음성으로 알려줄 수 있도록 자연스러운 문장으로 만들어주세요."}]
    local_messages.append({"role": "user", "content": prompt})
    # GPT 모델에서 스트리밍 텍스트 생성
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=local_messages,
    )

    content = response.choices[0].message.content
    print(content)
    # 텍스트를 음성으로 변환
    tts = gTTS(text=content, lang="ko")
    audio_data = BytesIO()
    tts.write_to_fp(audio_data)
    audio_data.seek(0)

    headers = {
        "Content-Type": "audio/mpeg",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
    }

    return StreamingResponse(audio_data, headers=headers)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level='info' , timeout_keep_alive=120)
    # subprocess.run(["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000", "--reload", "--log-level", "critical"])
