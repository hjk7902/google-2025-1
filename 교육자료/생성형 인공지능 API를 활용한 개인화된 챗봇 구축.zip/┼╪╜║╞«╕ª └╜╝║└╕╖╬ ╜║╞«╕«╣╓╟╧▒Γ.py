from openai import OpenAI
import sounddevice as sd
import numpy as np

client = OpenAI(
    api_key= "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"
)

# Audio settings
sample_rate = 24000
channels = 1


# Function to convert bytes to float32 numpy array
def bytes_to_float32(byte_data):
    # Convert the byte data to a numpy array of int16, then normalize to float32
    audio_data = np.frombuffer(byte_data, dtype=np.int16)
    return audio_data.astype(np.float32) / np.iinfo(np.int16).max


# Open an output audio stream
with sd.OutputStream(samplerate=sample_rate, channels=channels, dtype='float32') as stream:
    # Assuming `client.audio.speech.with_streaming_response.create` is a valid function
    with client.audio.speech.with_streaming_response.create(
            model="tts-1",
            voice="alloy",
            input="""I see skies of blue and clouds of white 
                The bright blessed days, the dark sacred nights
                And I think to myself
                What a wonderful world""",
            response_format="pcm"
    ) as response:
        for chunk in response.iter_bytes(1024):
            # Convert bytes to float32 numpy array
            float_data = bytes_to_float32(chunk)
            stream.write(float_data)